function normalizeBaseUrl(value) {
  const normalized = String(value || "").trim().replace(/\/+$/, "");
  if (!normalized) return "";
  return normalized.replace(/\/api$/, "");
}

export function deriveApiUrl() {
  const envUrl = typeof import.meta !== "undefined" ? import.meta.env?.VITE_API_URL : "";
  if (envUrl) return normalizeBaseUrl(envUrl);

  return "";
}

export const API_URL = deriveApiUrl();

export function deriveSocketUrl() {
  if (API_URL) return API_URL;
  return undefined;
}

export const SOCKET_URL = deriveSocketUrl();

export async function apiFetch(url, options = {}) {
  const tokenValue = localStorage.getItem("cutz_token") || "";
  const headers = {
    ...(options.headers || {}),
  };

  if (!headers["Content-Type"] && options.body) {
    headers["Content-Type"] = "application/json";
  }

  if (tokenValue) {
    headers.Authorization = `Bearer ${tokenValue}`;
  }

  let response;

  try {
    response = await fetch(`${API_URL}${url}`, {
      ...options,
      headers,
    });
  } catch {
    const target = API_URL || "same-origin /api";
    throw new Error(`Cannot reach the backend at ${target}. Start the backend and check VITE_API_URL or the reverse proxy.`);
  }

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    const message =
      typeof data === "string"
        ? data
        : data?.error || data?.message || "Request failed.";
    throw new Error(message);
  }

  return data;
}
