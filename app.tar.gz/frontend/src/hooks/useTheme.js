import { useEffect, useState } from "react";

export default function useTheme(storageKey = "cutz_theme", fallback = "dark") {
  const [theme, setTheme] = useState(() => localStorage.getItem(storageKey) || fallback);

  useEffect(() => {
    localStorage.setItem(storageKey, theme);
  }, [storageKey, theme]);

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.body.dataset.cutzTheme = theme;
    }
  }, [theme]);

  return [theme, setTheme];
}
