import { useState } from "react";
import { FiAlertTriangle, FiCalendar, FiMapPin, FiScissors } from "react-icons/fi";
import { FaStar } from "react-icons/fa";

function EmptyState({ title, text }) {
  return (
    <div className="empty-state-v7">
      <FiCalendar />
      <strong>{title}</strong>
      <span>{text}</span>
    </div>
  );
}

function canEditReview(review) {
  const createdAt = new Date(review?.createdAt || review?.created_at || Date.now()).getTime();
  return Number.isFinite(createdAt) && Date.now() - createdAt <= 24 * 60 * 60 * 1000;
}

export default function BookingsPage({
  role,
  bookings,
  completeBooking,
  approveBooking,
  rejectBooking,
  cancelBooking,
  confirmCashPayment,
  myBarberProfile,
  submitReview,
  editReview,
  deleteReview,
  reviewedBookings = {},
  barberMatchesBooking,
  formatTimeLabel,
}) {
  const [reviewDrafts, setReviewDrafts] = useState({});
  const [ratings, setRatings] = useState({});
  const [reviewErrors, setReviewErrors] = useState({});
  const [reportedReviews, setReportedReviews] = useState({});

  const isBarberView = role === "barber" && myBarberProfile;
  const visibleBookings = isBarberView
    ? bookings.filter((item) => barberMatchesBooking(item, myBarberProfile))
    : bookings;

  const submitBookingReview = async (booking) => {
    const text = String(reviewDrafts[booking.id] || "").trim();
    if (!ratings[booking.id]) {
      setReviewErrors((prev) => ({ ...prev, [booking.id]: "Choose a star rating first." }));
      return;
    }
    if (text.length < 8) {
      setReviewErrors((prev) => ({ ...prev, [booking.id]: "Write at least 8 characters before submitting." }));
      return;
    }
    setReviewErrors((prev) => ({ ...prev, [booking.id]: "" }));
    await submitReview(
      booking,
      Number(ratings[booking.id] || 5),
      text
    );
    setReviewDrafts((prev) => ({ ...prev, [booking.id]: "" }));
  };

  const editBookingReview = async (booking) => {
    const existingReview = reviewedBookings?.[String(booking.id)];
    const text = String(reviewDrafts[booking.id] ?? existingReview?.review_text ?? existingReview?.text ?? "").trim();
    if (!canEditReview(existingReview)) {
      setReviewErrors((prev) => ({ ...prev, [booking.id]: "Reviews can only be edited during the first 24 hours." }));
      return;
    }
    if (text.length < 8) {
      setReviewErrors((prev) => ({ ...prev, [booking.id]: "Keep your review useful with at least 8 characters." }));
      return;
    }
    setReviewErrors((prev) => ({ ...prev, [booking.id]: "" }));
    await editReview(
      booking,
      Number(ratings[booking.id] || reviewedBookings?.[String(booking.id)]?.rating || 5),
      text
    );
  };

  return (
    <div className="content-v4 standard-page-v4">
      <div className="panel-title-v4">{isBarberView ? "Incoming bookings" : "My bookings"}</div>
      <div className="booking-list-v4 space-top">
        {visibleBookings.length === 0 ? (
          <EmptyState
            title={isBarberView ? "No incoming bookings yet" : "No bookings yet"}
            text={isBarberView ? "New customer appointments will land here for approval." : "Book a barber and your appointment details will appear here."}
          />
        ) : (
          visibleBookings.map((booking) => (
            <div key={booking.id} className="simple-card-v4">
              <div className="booking-name-v4">{isBarberView ? (booking.customerName || booking.customerUsername) : booking.barberName}</div>
              {booking.teamMemberName ? (
                <div className="booking-meta-v4">
                  <FiScissors /> Barber: {booking.teamMemberName}
                </div>
              ) : null}
              <div className="booking-meta-v4">
                <FiCalendar /> {booking.date} · {booking.timeLabel || formatTimeLabel(booking.time)}
              </div>
              <div className="booking-meta-v4">
                <FiScissors /> {booking.service || "Haircut"}
              </div>
              <div className="booking-meta-v4">
                <FiMapPin /> {booking.location || "Location unavailable"}
              </div>
              <div className="booking-meta-v4">
                Payment: {(booking.paymentMethod || "cash") === "wallet" ? "Wallet" : "Cash"} · {booking.paymentStatus || "unpaid"}
              </div>
              <div className="inline-actions-v4">
                <span className={`booking-badge-v4 status-${booking.status || "pending"}`}>{booking.status}</span>
                {isBarberView && booking.status === "pending" && (
                  <>
                    <button className="mini-action-btn-v4 success" onClick={() => approveBooking(booking.id)}>Approve</button>
                    <button className="mini-action-btn-v4 danger" onClick={() => rejectBooking(booking.id)}>Reject</button>
                  </>
                )}
                {isBarberView && booking.status === "confirmed" && (
                  <button className="mini-action-btn-v4 success" onClick={() => completeBooking(booking.id)}>Mark done</button>
                )}
                {isBarberView && booking.paymentMethod === "cash" && booking.paymentStatus !== "paid" && (
                  <button className="mini-action-btn-v4 success" onClick={() => confirmCashPayment(booking.id)}>Confirm cash</button>
                )}
                {!isBarberView && (booking.status === "pending" || booking.status === "confirmed") && (
                  <button className="mini-action-btn-v4 danger" onClick={() => cancelBooking(booking.id)}>Cancel</button>
                )}
              </div>

              {!isBarberView && booking.status === "completed" && (
                <div className="booking-summary-v4">
                  {reviewedBookings?.[String(booking.id)] ? (
                    <>
                      {(() => {
                        const existingReview = reviewedBookings[String(booking.id)];
                        const canEdit = canEditReview(existingReview);
                        return (
                        <>
                      <div className="review-policy-v7">
                        <FiAlertTriangle />
                        <span>{canEdit ? "You can edit this review for 24 hours after posting." : "The edit window has closed, but you can still report abuse."}</span>
                      </div>
                      {existingReview?.id ? (
                        <>
                          <div className="panel-title-v4 small-title-v4">Edit your review</div>
                          <div className="star-input-v4">
                            {[1, 2, 3, 4, 5].map((n) => (
                              <button
                                type="button"
                                key={n}
                                className={Number(ratings[booking.id] || reviewedBookings[String(booking.id)]?.rating || 0) >= n ? "star-hit-v4 active" : "star-hit-v4"}
                                onClick={() => setRatings((prev) => ({ ...prev, [booking.id]: n }))}
                              >
                                <FaStar />
                              </button>
                            ))}
                          </div>
                          <textarea
                            className="textarea-v4"
                            placeholder="Update your review"
                            value={reviewDrafts[booking.id] ?? reviewedBookings[String(booking.id)]?.review_text ?? reviewedBookings[String(booking.id)]?.text ?? ""}
                            onChange={(e) =>
                              setReviewDrafts((prev) => ({ ...prev, [booking.id]: e.target.value }))
                            }
                          />
                          <div className="inline-actions-v4">
                            <button className="secondary-btn-v4" onClick={() => editBookingReview(booking)} disabled={!canEdit}>
                              Save review
                            </button>
                            <button className="secondary-btn-v4 danger-outline" onClick={() => deleteReview(booking)}>
                              Delete review
                            </button>
                            <button
                              type="button"
                              className="secondary-btn-v4"
                              onClick={() => setReportedReviews((prev) => ({ ...prev, [booking.id]: true }))}
                              disabled={reportedReviews[booking.id]}
                            >
                              {reportedReviews[booking.id] ? "Reported" : "Report review"}
                            </button>
                          </div>
                          {reviewErrors[booking.id] ? <div className="auth-error">{reviewErrors[booking.id]}</div> : null}
                        </>
                      ) : null}
                        </>
                        );
                      })()}
                    </>
                  ) : (
                    <>
                      <div className="panel-title-v4 small-title-v4">Rate {booking.barberName}</div>
                      <div className="profile-sub-v4">Tap the stars to choose your rating.</div>
                      <div className="star-input-v4">
                        {[1, 2, 3, 4, 5].map((n) => (
                          <button
                            type="button"
                            key={n}
                            className={Number(ratings[booking.id] || 0) >= n ? "star-hit-v4 active" : "star-hit-v4"}
                            onClick={() => setRatings((prev) => ({ ...prev, [booking.id]: n }))}
                          >
                            <FaStar />
                          </button>
                        ))}
                      </div>
                      <textarea
                        className="textarea-v4"
                        placeholder="How was your experience?"
                        value={reviewDrafts[booking.id] || ""}
                        onChange={(e) =>
                          setReviewDrafts((prev) => ({ ...prev, [booking.id]: e.target.value }))
                        }
                      />
                      <button
                        className="secondary-btn-v4"
                        onClick={() => submitBookingReview(booking)}
                      >
                        Submit review
                      </button>
                      {reviewErrors[booking.id] ? <div className="auth-error">{reviewErrors[booking.id]}</div> : null}
                    </>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}



