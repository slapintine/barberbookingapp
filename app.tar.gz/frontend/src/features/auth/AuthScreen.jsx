import { useState } from "react";
import { FiLock, FiUser } from "react-icons/fi";
import logo from "../../assets/logo.png";

export default function AuthScreen(props) {
  const {
    authMode,
    setAuthMode,
    authError,
    authSuccess,
    authLoading,
    usernameRef,
    passwordRef,
    confirmPasswordRef,
    handleLogin,
    handleRegister,
    sendPasswordResetCode,
    handlePasswordReset,
    clearAuthMessages,
  } = props;
  const [resetCooldown, setResetCooldown] = useState(0);
  const isReset = authMode === "reset";
  const isForgot = authMode === "forgot";
  const title = isReset
    ? "Enter reset code"
    : isForgot
    ? "Forgot password"
    : authMode === "login"
    ? "Welcome back"
    : "Create account";

  return (
    <div className="auth-screen-v4">
      <div className="auth-card-v4">
        <img src={logo} alt="Cutz" className="auth-logo-v4" />
        <h1 className="auth-title-v4">{title}</h1>
        {authMode === "signup" ? (
          <div className="auth-sub-v4">
            Sign up fast with just your username and password. Add the rest in Profile later.
          </div>
        ) : null}

        {!isForgot && !isReset ? (
          <div className="auth-switch-v4">
            <button
              type="button"
              className={authMode === "login" ? "switch-btn active" : "switch-btn"}
              onClick={() => {
                setAuthMode("login");
                clearAuthMessages();
              }}
            >
              Log In
            </button>
            <button
              type="button"
              className={authMode === "signup" ? "switch-btn active" : "switch-btn"}
              onClick={() => {
                setAuthMode("signup");
                clearAuthMessages();
              }}
            >
              Sign Up
            </button>
          </div>
        ) : null}

        {isForgot ? (
          <div className="auth-sub-v4">
            Enter your username or email. We will send a verification code before you choose a new password.
          </div>
        ) : null}
        {isReset ? (
          <div className="auth-sub-v4">
            Email sent. Enter the verification code and your new password.
          </div>
        ) : null}

        <div className="field-row">
          <FiUser className="field-icon" />
          <input
            ref={usernameRef}
            className="field-input-v4"
            placeholder={isReset || isForgot ? "Username or email" : "Username"}
          />
        </div>

        {!isForgot ? (
          <div className="field-row">
            <FiLock className="field-icon" />
            <input
              ref={passwordRef}
              className="field-input-v4"
              type={isReset ? "text" : "password"}
              placeholder={isReset ? "Verification code" : "Password"}
            />
          </div>
        ) : null}

        {(authMode === "signup" || isReset) && (
          <div className="field-row">
            <FiLock className="field-icon" />
            <input
              ref={confirmPasswordRef}
              className="field-input-v4"
              type="password"
              placeholder={isReset ? "New password" : "Confirm Password"}
            />
          </div>
        )}

        {authError && <div className="auth-error">{authError}</div>}
        {authSuccess && <div className="auth-success">{authSuccess}</div>}

        {isForgot ? (
          <>
            <button
              className="primary-btn-v4"
              onClick={async () => {
                const sent = await sendPasswordResetCode();
                if (sent) {
                  setResetCooldown(45);
                  const timer = setInterval(() => {
                    setResetCooldown((value) => {
                      if (value <= 1) {
                        clearInterval(timer);
                        return 0;
                      }
                      return value - 1;
                    });
                  }, 1000);
                }
              }}
              disabled={authLoading || resetCooldown > 0}
            >
              {authLoading ? "Sending..." : resetCooldown > 0 ? `Resend in ${resetCooldown}s` : "Send email code"}
            </button>
            <div className="cooldown-note-v7">Reset codes can be requested every 45 seconds.</div>
          </>
        ) : null}

        {!isForgot ? (
          <button
            className="primary-btn-v4"
            onClick={isReset ? handlePasswordReset : authMode === "login" ? handleLogin : handleRegister}
            disabled={authLoading}
          >
            {authLoading ? "Please wait..." : isReset ? "Reset Password" : authMode === "login" ? "Log In" : "Create Account"}
          </button>
        ) : null}
        {authMode === "login" ? (
          <button
            type="button"
            className="text-btn-v4"
            onClick={() => {
              setAuthMode("forgot");
              clearAuthMessages();
            }}
          >
            Forgot password?
          </button>
        ) : null}
        {isForgot || isReset ? (
          <button
            type="button"
            className="text-btn-v4"
            onClick={() => {
              setAuthMode("login");
              clearAuthMessages();
            }}
          >
            Back to login
          </button>
        ) : null}
      </div>
    </div>
  );
}
