import { apiFetch } from "../config/api.js";

export function getBarberReviews(barberId) {
  return apiFetch(`/api/reviews/barber/${barberId}`);
}

export function createReview(payload) {
  return apiFetch("/api/reviews", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function updateReview(reviewId, payload) {
  return apiFetch(`/api/reviews/${reviewId}`, {
    method: "PATCH",
    body: JSON.stringify(payload),
  });
}

export function deleteReview(reviewId) {
  return apiFetch(`/api/reviews/${reviewId}`, {
    method: "DELETE",
  });
}

export function getMyReviews() {
  return apiFetch("/api/reviews/me");
}
