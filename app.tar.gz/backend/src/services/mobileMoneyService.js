import { env } from "../config/env.js";
import { airtelService } from "./airtel.service.js";
import { mockMobileMoneyService } from "./mockMobileMoneyService.js";
import { mtnService } from "./mtn.service.js";

function isLiveConfigured() {
  return Boolean(
    (env.mtnApiKey && env.mtnApiSecret && env.mtnCollectionUrl && env.mtnVerificationUrl && env.mtnDisbursementUrl) ||
      (env.airtelApiKey &&
        env.airtelApiSecret &&
        env.airtelCollectionUrl &&
        env.airtelVerificationUrl &&
        env.airtelDisbursementUrl)
  );
}

function resolveDefaultService() {
  const mode = String(env.mobileMoneyMode || "mock").trim().toLowerCase();

  if (mode === "mock") {
    return mockMobileMoneyService;
  }

  if (mode === "live" || (mode === "auto" && isLiveConfigured())) {
    return String(env.mobileMoneyDefaultProvider || "mtn").trim().toLowerCase() === "airtel"
      ? airtelService
      : mtnService;
  }

  return mockMobileMoneyService;
}

function resolveProviderService(provider) {
  const normalizedProvider = String(provider || "").trim().toLowerCase();

  if (String(env.mobileMoneyMode || "mock").trim().toLowerCase() === "mock") {
    return mockMobileMoneyService;
  }

  if (normalizedProvider === "airtel_money") return airtelService;
  if (normalizedProvider === "mtn_mobile_money") return mtnService;

  return resolveDefaultService();
}

export function getMobileMoneyService(provider) {
  const service = provider ? resolveProviderService(provider) : resolveDefaultService();

  return {
    providerKey: service.providerKey,
    initiateCollection(input) {
      return resolveProviderService(input?.provider || provider || service.providerKey).initiateCollection(input);
    },
    verifyTransaction(input) {
      return resolveProviderService(input?.provider || provider || service.providerKey).verifyTransaction(input);
    },
    disburseFunds(input) {
      return resolveProviderService(input?.provider || provider || service.providerKey).disburseFunds(input);
    },
  };
}
