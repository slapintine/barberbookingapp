import { logger } from "../config/logger.js";

export function logProviderRequest({ provider, operation, endpoint, request, credentials = {} }) {
  logger.info({
    domain: "mobile_money",
    provider,
    operation,
    stage: "request",
    endpoint,
    credentials,
    payload: request,
  });
}

export function logProviderResponse({ provider, operation, endpoint, statusCode, response }) {
  logger.info({
    domain: "mobile_money",
    provider,
    operation,
    stage: "response",
    endpoint,
    statusCode,
    payload: response,
  });
}
