import { transaction } from "../db/query.js";
import { env } from "../config/env.js";
import { createReference, normalizePhoneNumber } from "../services/paymentService.js";
import { getMobileMoneyService } from "../services/mobileMoneyService.js";
import {
  createPaymentRecord,
  getPaymentRecordByBookingId,
  getPaymentRecordByReference,
  normalizeLifecycleStatus,
  updatePaymentRecord,
} from "../services/paymentDataService.js";
import { getMyWallet, requestWithdrawal } from "./walletController.js";
import { handleBookingPaymentWebhook, verifyBookingPayment } from "./bookingController.js";

function httpError(statusCode, message) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function getBookingById(bookingId, client = { get }) {
  return client.get(`SELECT * FROM bookings WHERE id = ?`, [bookingId]);
}

async function getBarberById(barberId, client = { get }) {
  return client.get(
    `SELECT b.id, b.owner_user_id, b.business_name, p.phone
     FROM barbers b
     LEFT JOIN profiles p ON p.user_id = b.owner_user_id
     WHERE b.id = ?`,
    [barberId]
  );
}

async function getCustomerPhone(userId, client = { get }) {
  const profile = await client.get(`SELECT phone FROM profiles WHERE user_id = ?`, [userId]);
  return normalizePhoneNumber(profile?.phone || "");
}

export async function checkout(req, res, next) {
  try {
    const bookingId = Number(req.body.bookingId || req.body.booking_id);
    const provider = String(req.body.provider || "").trim().toLowerCase();
    const idempotencyKey = String(req.body.idempotencyKey || req.get("Idempotency-Key") || "").trim().slice(0, 120);

    if (!Number.isInteger(bookingId) || bookingId <= 0) {
      throw httpError(400, "bookingId is required.");
    }

    const result = await transaction(async (client) => {
      const booking = await getBookingById(bookingId, client);
      if (!booking) {
        throw httpError(404, "Booking not found.");
      }

      if (Number(booking.customer_user_id) !== Number(req.user.id)) {
        throw httpError(403, "Only the customer can start checkout for this booking.");
      }

      const paymentProvider = provider || String(booking.payment_method || "").trim().toLowerCase();
      if (!["mtn_mobile_money", "airtel_money"].includes(paymentProvider)) {
        throw httpError(400, "Checkout only supports MTN or Airtel mobile money bookings.");
      }

      if (booking.payment_status === "paid") {
        const existingPaid = await getPaymentRecordByBookingId(bookingId, client);
        return { booking, payment: existingPaid, alreadyPaid: true };
      }

      const existingPayment = await getPaymentRecordByBookingId(bookingId, client);
      if (existingPayment && ["pending", "initiated", "successful"].includes(String(existingPayment.status || "").toLowerCase())) {
        return { booking, payment: existingPayment, alreadyStarted: true };
      }

      const barber = await getBarberById(booking.barber_id, client);
      const payerPhone = normalizePhoneNumber(req.body.phoneNumber || req.body.phone_number || booking.payment_customer_phone || (await getCustomerPhone(req.user.id, client)));
      if (!payerPhone) {
        throw httpError(400, "A valid customer phone number is required for mobile money checkout.");
      }

      const reference = booking.payment_reference || createReference("booking", booking.id);
      const callbackUrl = `${env.appPublicUrl}/api/payments/webhooks/${paymentProvider === "airtel_money" ? "airtel" : "mtn"}`;
      const providerResult = await getMobileMoneyService(paymentProvider).initiateCollection({
        provider: paymentProvider,
        amount: Number(booking.price || 0),
        phoneNumber: payerPhone,
        reference,
        description: `Booking payment for ${barber?.business_name || "barber booking"}`,
        callbackUrl,
      });
      const paymentStatus = normalizeLifecycleStatus(providerResult.status, "initiated");

      await client.run(
        `UPDATE bookings
         SET payment_reference = ?,
             payment_provider = ?,
             payment_customer_phone = ?,
             payment_status = CASE
               WHEN payment_status = 'paid' THEN payment_status
               ELSE 'pending'
             END,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [reference, paymentProvider, payerPhone, booking.id]
      );

      if (existingPayment) {
        await updatePaymentRecord({
          client,
          internalReference: existingPayment.internal_reference,
          providerReference: providerResult.providerReference || existingPayment.provider_reference || "",
          status: paymentStatus,
          metadata: providerResult.rawResponse || {},
        });

        await client.run(
          `UPDATE payment_transactions
           SET provider_reference = ?,
               payer_phone = ?,
               status = ?,
               metadata = ?,
               updated_at = CURRENT_TIMESTAMP
           WHERE internal_reference = ?`,
          [
            providerResult.providerReference || existingPayment.provider_reference || "",
            payerPhone,
            paymentStatus,
            JSON.stringify(providerResult.rawResponse || {}),
            existingPayment.internal_reference,
          ]
        );
      } else {
        await createPaymentRecord({
          client,
          bookingId: booking.id,
          barberId: booking.barber_id,
          userId: booking.customer_user_id,
          flowType: "booking",
          provider: paymentProvider,
          internalReference: reference,
          providerReference: providerResult.providerReference || "",
          callbackUrl,
          idempotencyKey,
          payerPhone,
          payeePhone: barber?.phone || "",
          grossAmount: Number(booking.price || 0),
          commissionAmount: Number(booking.commission_amount || 0),
          barberAmount: Number(booking.barber_amount || 0),
          status: paymentStatus,
          metadata: providerResult.rawResponse || {},
        });

        await client.run(
          `INSERT INTO payment_transactions
           (booking_id, barber_id, user_id, transaction_type, provider, internal_reference, provider_reference, idempotency_key, payer_phone, payee_phone, gross_amount, commission_amount, net_amount, currency, status, metadata)
           VALUES (?, ?, ?, 'booking_payment', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UGX', ?, ?)`,
          [
            booking.id,
            booking.barber_id,
            booking.customer_user_id,
            paymentProvider,
            reference,
            providerResult.providerReference || "",
            idempotencyKey,
            payerPhone,
            barber?.phone || "",
            Number(booking.price || 0),
            Number(booking.commission_amount || 0),
            Number(booking.barber_amount || 0),
            paymentStatus,
            JSON.stringify(providerResult.rawResponse || {}),
          ]
        );
      }

      return {
        booking: await getBookingById(booking.id, client),
        payment: await getPaymentRecordByReference({ reference }, client),
      };
    });

    res.status(200).json({
      success: true,
      already_paid: Boolean(result.alreadyPaid),
      already_started: Boolean(result.alreadyStarted),
      booking: result.booking,
      payment: result.payment,
    });
  } catch (error) {
    next(error);
  }
}

export async function verify(req, res, next) {
  try {
    const bookingId = Number(req.body.bookingId || req.body.booking_id || req.params.id);
    let resolvedBookingId = bookingId;

    if (!resolvedBookingId) {
      const reference = String(req.body.reference || req.body.payment_reference || "").trim();
      const providerReference = String(req.body.providerReference || req.body.provider_reference || "").trim();
      if (!reference && !providerReference) {
        throw httpError(400, "bookingId or payment reference is required.");
      }

      const payment = await transaction(async (client) =>
        getPaymentRecordByReference({ reference, providerReference }, client)
      );
      if (!payment?.booking_id) {
        throw httpError(404, "Payment not found.");
      }
      resolvedBookingId = Number(payment.booking_id);
    }

    req.params.id = String(resolvedBookingId);
    return verifyBookingPayment(req, res, next);
  } catch (error) {
    next(error);
  }
}

export async function handleMtnWebhook(req, res, next) {
  req.body = {
    ...(req.body || {}),
    provider: "mtn_mobile_money",
  };
  return handleBookingPaymentWebhook(req, res, next);
}

export async function handleAirtelWebhook(req, res, next) {
  req.body = {
    ...(req.body || {}),
    provider: "airtel_money",
  };
  return handleBookingPaymentWebhook(req, res, next);
}

export async function getWalletSummary(req, res, next) {
  return getMyWallet(req, res, next);
}

export async function requestPayout(req, res, next) {
  return requestWithdrawal(req, res, next);
}
