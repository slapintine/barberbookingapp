CREATE TABLE IF NOT EXISTS payments (
  id BIGSERIAL PRIMARY KEY,
  booking_id BIGINT REFERENCES bookings(id) ON DELETE SET NULL,
  barber_id BIGINT REFERENCES barbers(id) ON DELETE SET NULL,
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  flow_type TEXT NOT NULL DEFAULT 'booking',
  provider TEXT NOT NULL DEFAULT 'internal',
  internal_reference TEXT NOT NULL UNIQUE,
  provider_reference TEXT DEFAULT '',
  callback_url TEXT DEFAULT '',
  idempotency_key TEXT DEFAULT '',
  payer_phone TEXT DEFAULT '',
  payee_phone TEXT DEFAULT '',
  gross_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  commission_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  barber_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'UGX',
  status TEXT NOT NULL DEFAULT 'pending',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payments_booking_id
  ON payments(booking_id);

CREATE INDEX IF NOT EXISTS idx_payments_reference
  ON payments(internal_reference);

CREATE INDEX IF NOT EXISTS idx_payments_provider_reference
  ON payments(provider_reference);

CREATE INDEX IF NOT EXISTS idx_payments_idempotency
  ON payments(user_id, idempotency_key);

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id BIGSERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id BIGINT,
  wallet_id BIGINT REFERENCES barber_wallets(id) ON DELETE SET NULL,
  booking_id BIGINT REFERENCES bookings(id) ON DELETE SET NULL,
  payment_id BIGINT REFERENCES payments(id) ON DELETE SET NULL,
  payout_id BIGINT,
  direction TEXT NOT NULL,
  balance_bucket TEXT NOT NULL,
  amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  reference TEXT DEFAULT '',
  provider_reference TEXT DEFAULT '',
  description TEXT DEFAULT '',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wallet_ledger_owner
  ON wallet_ledger(owner_type, owner_id);

CREATE INDEX IF NOT EXISTS idx_wallet_ledger_payment
  ON wallet_ledger(payment_id);

CREATE INDEX IF NOT EXISTS idx_wallet_ledger_booking
  ON wallet_ledger(booking_id);

CREATE TABLE IF NOT EXISTS payouts (
  id BIGSERIAL PRIMARY KEY,
  barber_id BIGINT NOT NULL REFERENCES barbers(id) ON DELETE CASCADE,
  wallet_id BIGINT NOT NULL REFERENCES barber_wallets(id) ON DELETE CASCADE,
  amount DOUBLE PRECISION NOT NULL,
  mobile_money_number TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'mtn_mobile_money',
  internal_reference TEXT NOT NULL UNIQUE,
  provider_reference TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  idempotency_key TEXT DEFAULT '',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  note TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payouts_barber_id
  ON payouts(barber_id);

CREATE INDEX IF NOT EXISTS idx_payouts_wallet_id
  ON payouts(wallet_id);

CREATE INDEX IF NOT EXISTS idx_payouts_idempotency
  ON payouts(barber_id, idempotency_key);

CREATE TABLE IF NOT EXISTS webhook_events (
  id BIGSERIAL PRIMARY KEY,
  provider TEXT NOT NULL,
  event_type TEXT NOT NULL DEFAULT 'payment_callback',
  reference TEXT DEFAULT '',
  provider_reference TEXT DEFAULT '',
  signature TEXT DEFAULT '',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  processing_status TEXT NOT NULL DEFAULT 'received',
  processed_at TIMESTAMPTZ DEFAULT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_webhook_events_reference
  ON webhook_events(reference, provider_reference);

CREATE INDEX IF NOT EXISTS idx_webhook_events_provider
  ON webhook_events(provider, event_type);
